#ifndef __LIGHT_H__
#define __LIGHT_H__
#include "Angel.h"

class Light {
	//TODO
};


#endif
