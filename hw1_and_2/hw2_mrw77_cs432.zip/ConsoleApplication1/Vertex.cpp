#include "Vertex.h"


Vertex::Vertex(){}

Vertex::Vertex(vec3 _position, vec4 _color){
	position = _position;
    color = _color;
}