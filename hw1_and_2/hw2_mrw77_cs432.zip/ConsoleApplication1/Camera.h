#ifndef __CAMERA_H__
#define __CAMERA_H__
#include "Angel.h"

class Camera {
	//TODO
};

#endif
