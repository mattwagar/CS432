Matthew Wagar
CS432
HW2

OS: Windows 10
IDE: Visual Studio 2012
Shader Version: 150

How to run:
1. Open "ConsoleApplication1.sln" in visual studio
2. Press the play button "Local Windows Debugger"

(make sure your IDE is configured for glew/freeglut)


Notes: I DID THE EXTRA CREDIT <3. 

Also For some reason my program starts black until you click into it. Not sure why. 
Otherwise works perfectly

