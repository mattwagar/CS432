Matthew Wagar
CS432
HW2

OS: Windows 10
IDE: Visual Studio 2012
Shader Version: 150

How to run:
1. Open "ConsoleApplication1.sln" in visual studio
2. Press the play button "Local Windows Debugger"

(make sure your IDE is configured for glew/freeglut)


Notes: I ran into a weird bug when I loaded it with cube. It works best if you just load Icosahedron alone.

